To install, just right-click then click install.

If using an older system, move "Vampyrium Font.tff" into the "Fonts" folder located in the control panel.

Thank "Mod Rowley" and the artist behind the font(I have no idea who that is sadly :c) for the font <3

NOTE FROM ROWLEY(@JagexRowley):
"The tribe symbol letters should always be larger (always capitalised) - that's the A, D, G, J, M, P, S and V - to honour them"

Copyright � 2015 Jagex Ltd.

Jagex Limited hereby grants a revocable, limited, non-exclusive, non-transferable, non-sublicensable licence to any person obtaining a copy of this Myreque VI font software (the "Software") to use, copy and modify the Software for non-commercial purposes only, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies of the Software.
The Software must not be used for any unlawful purposes.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. TO THE FULLEST EXTENT PERMITTED BY LAW, IN NO EVENT SHALL THE AUTHOR OR COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, INCLUDING ANY GENERAL, SPECIAL, DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
Jagex may terminate this licence at any time for any or no reason.  Upon such termination all use of the Software must cease. 
This licence is subject to English law and the exclusive jurisdiction of the courts of England.